Scriptname FHSRTW_Config extends SKI_ConfigBase

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                    Properties
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
GlobalVariable Property TimeScale    Auto               ; 타임스케일 전역
GlobalVariable Property GameHour     Auto               ; 현재 게임 시간
Actor          Property PlayerREF    Auto               ; 플레이어 참조
Spell          Property Time_Waiting Auto               ; 대기 중 적용할 스펠(선택)

;--- MCM 제어 값
Int   Property Hotkey      = 21     Auto Hidden        ; 기본 F
Float Property TargetScale = 120.0  Auto Hidden        ; 목표 타임스케일 (MCM, 안전 상한)
Float Property RampStep    = 20.0   Auto Hidden        ; 증감 스텝(내부)

;--- 내부 상태
Bool  Property WaitMode   = False Auto Hidden          ; 대기 모드 토글
Float ScaleOriginal       = 20.0                       ; 진입 시 원래 스케일 저장
Bool  Property DidSitAnim = False Auto Hidden          ; 앉기 애니 사용 여부 트래킹

;--- MCM 항목 핸들
Int ItemHotkey
Int ItemTarget

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                MCM Identity (Strings 연동)
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
String Function GetName()
    return "FHSRTW"
EndFunction

String Function GetTitle()
    return "$FHSRTW_Mod_Title"
EndFunction

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                 Internal Helpers
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bool Function IsInAnyMenu()
    If Utility.IsInMenuMode()
        return True
    EndIf
    return False
EndFunction

Function ApplySettings()
    UnregisterForKey(Hotkey)
    RegisterForKey(Hotkey)
EndFunction

Function DebugShowCurrentTime()
    If GameHour
        Float t = GameHour.GetValue()
        Int h = (Math.Floor(t) as Int)
        Int m = ((Math.Floor(t * 60)) % 60) as Int
        If (m < 10)
            Debug.Notification("Time: " + h + ":0" + m)
        Else
            Debug.Notification("Time: " + h + ":" + m)
        EndIf
    EndIf
EndFunction

; 안전한 앉기 종료 시퀀스 (PlayIdle 우선, 이벤트 폴백)
Idle Property IdleSitCrossLeggedExit Auto ; CK에서 Idle 폼 연결 권장 (없어도 이벤트 폴백 사용)

Function PlaySafeSitExit()
    ; 안전한 일어서기: 강제 리셋을 제거하여 모션 끊김을 방지합니다.
    If PlayerREF
        ; 1) 가장 확실한 애니메이션 이벤트 전송
        Debug.SendAnimationEvent(PlayerREF, "IdleSitCrossLeggedExit")
        
        ; 2) Idle Property가 설정되어 있다면 함께 실행 (정상적인 블렌딩 유도)
        If IdleSitCrossLeggedExit
            PlayerREF.PlayIdle(IdleSitCrossLeggedExit)
        EndIf
    EndIf
EndFunction

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                Lock / Unlock Controls
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function LockControls()
    Game.DisablePlayerControls( \
        abMovement   = True, \
        abFighting   = False, \
        abCamSwitch  = False, \
        abLooking    = False, \
        abSneaking   = False, \
        abMenu       = False, \
        abActivate   = True, \
        abJournalTabs= False, \
        aiDisablePOVType = 0 )
EndFunction

Function UnlockControls()
    Game.EnablePlayerControls( \
        abMovement   = True, \
        abFighting   = True, \
        abCamSwitch  = True, \
        abLooking    = True, \
        abSneaking   = True, \
        abMenu       = True, \
        abActivate   = True, \
        abJournalTabs= True, \
        aiDisablePOVType = 0 )
EndFunction

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                Start / Stop Logic
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function StartRealTimeWait()
    ; 전투 상태면 사용 불가
    If PlayerREF && PlayerREF.IsInCombat()
        Debug.Notification("$FHSRTW_EnemyNearby")
        return
    EndIf

    ; 안전 상한으로 목표값 클램프 (과도 가속 방지)
    Float MaxSafe = 120.0
    If TargetScale > MaxSafe
        TargetScale = MaxSafe
    EndIf

    ScaleOriginal = TimeScale.GetValue()
    WaitMode = True

    LockControls()

    ; 납도 방지
    Utility.Wait(0.1)
    If PlayerREF.IsWeaponDrawn()
        PlayerREF.DrawWeapon()
    EndIf

    ; OAR 컨디션 대응: 애니메이션 실행 전 스펠을 먼저 캐스팅하여 조건을 충족시킵니다.
    If Time_Waiting
        Time_Waiting.Cast(PlayerREF, PlayerREF)
        Utility.Wait(0.1) ; 스펠 적용이 엔진에 인식될 짧은 시간 대기
    EndIf

    ; 무기를 꺼내 들고 있지 않으면, 앉기 진입 + 루프 고정
    If PlayerREF && !PlayerREF.IsWeaponDrawn()
        Debug.SendAnimationEvent(PlayerREF, "IdleSitCrossLeggedEnter")
        DidSitAnim = True
        Utility.Wait(0.15)
        Debug.SendAnimationEvent(PlayerREF, "IdleSitCrossLegged") ; 루프 상태 진입
    Else
        DidSitAnim = False
    EndIf

    ; 목표 타임스케일까지 점진 증가
    While WaitMode && (TimeScale.GetValue() < TargetScale)
        ; 실시간 전투 감지 → 즉시 종료
        If PlayerREF && PlayerREF.IsInCombat()
            Debug.Notification("$FHSRTW_EnemyDetected")
            StopRealTimeWait()
            Return
        EndIf

        Float nextUp = TimeScale.GetValue() + RampStep
        If nextUp > TargetScale
            nextUp = TargetScale
        EndIf
        TimeScale.SetValue(nextUp)
        Utility.Wait(0.05)
    EndWhile
EndFunction

Function StopRealTimeWait()
    WaitMode = False

    ; 원래 타임스케일까지 점진 감소
    While TimeScale.GetValue() > ScaleOriginal
        Float nextDown = TimeScale.GetValue() - RampStep
        If nextDown < ScaleOriginal
            nextDown = ScaleOriginal
        EndIf
        TimeScale.SetValue(nextDown)
        Utility.Wait(0.05)
    EndWhile

    TimeScale.SetValue(ScaleOriginal)

    ; 앉기 사용했으면 일으키기 (Exit → 스펠 해제 순서로 OAR 유지)
    If DidSitAnim && PlayerREF
        PlaySafeSitExit()
        Utility.Wait(0.1) ; 일어서기 트리거가 확실히 들어가기 위한 대기
        DidSitAnim = False
    EndIf

    ; 대기 스펠 해제 (일어서기 트리거 이후에 수행)
    If Time_Waiting
        PlayerREF.DispelSpell(Time_Waiting)
    EndIf

    ; ✅ 안정화 틱: 큐 소화/패키지 평가
    Utility.Wait(0.3)
    If PlayerREF
        PlayerREF.EvaluatePackage()
    EndIf

    UnlockControls()
EndFunction

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                    SKI / MCM
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Event OnConfigInit()
    ApplySettings()
EndEvent

Event OnGameReload()
    parent.OnGameReload()
    ApplySettings()
EndEvent

Event OnPageReset(String page)
    SetCursorFillMode(TOP_TO_BOTTOM)
    SetCursorPosition(0)
    AddHeaderOption("$FHSRTW_MenuOpt_HeaderSettings")
    ItemHotkey = AddKeyMapOption("$FHSRTW_MenuOpt_Hotkey", Hotkey)
    ; 🔽 MCM 최대값 120.0으로 제한
    ItemTarget = AddSliderOption("$FHSRTW_MenuOpt_TimeScale", TargetScale, "{0}")
EndEvent

Event OnOptionHighlight(Int item)
    String tip = ""
    If item == ItemHotkey
        tip = "$FHSRTW_MenuTip_Hotkey"
    ElseIf item == ItemTarget
        tip = "$FHSRTW_MenuTip_TimeScale"
    EndIf
    SetInfoText(tip)
EndEvent

Event OnOptionSliderOpen(Int item)
    Float val = 0.0
    Float min = 0.0
    Float max = 0.0
    Float step = 0.0

    If item == ItemTarget
        val  = TargetScale
        min  = 5.0
        max  = 120.0 ; ✅ 최대값 제한 (기존 500 → 120)
        step = 5.0
    EndIf

    SetSliderDialogStartValue(val)
    SetSliderDialogRange(min, max)
    SetSliderDialogInterval(step)
EndEvent

Event OnOptionSliderAccept(Int item, Float val)
    If item == ItemTarget
        TargetScale = val
        SetSliderOptionValue(item, val, "{0}")
    EndIf
EndEvent

Event OnOptionKeyMapChange(Int option, Int keyCode, String conflictControl, String conflictName)
    If option == ItemHotkey
        Bool proceed = True
        If (conflictControl != "")
            String msg
            If (conflictName != "")
                msg = "This key is already mapped to:\n\"" + conflictControl + "\"\n(" + conflictName + ")\n\nAre you sure you want to continue?"
            Else
                msg = "This key is already mapped to:\n\"" + conflictControl + "\"\n\nAre you sure you want to continue?"
            EndIf
            proceed = ShowMessage(msg, True, "$Yes", "$No")
        EndIf

        If proceed
            UnregisterForKey(Hotkey)
            Hotkey = keyCode
            SetKeymapOptionValue(ItemHotkey, keyCode)
            RegisterForKey(keyCode)
        EndIf
    EndIf
EndEvent

;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
;                     Input
;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Event OnKeyDown(Int keyCode)
    If keyCode != Hotkey
        return
    EndIf

    If IsInAnyMenu()
        return
    EndIf

    If !WaitMode
        If PlayerREF && PlayerREF.IsInCombat()
            Debug.Notification("$FHSRTW_EnemyNearby")
            return
        EndIf
        StartRealTimeWait()
    Else
        StopRealTimeWait()
        DebugShowCurrentTime()
    EndIf
EndEvent
