Scriptname FHSRTW_EyeControl extends ActiveMagicEffect

Event OnEffectStart(Actor akTarget, Actor akCaster)
    if akTarget
        ConsoleUtil.SetSelectedReference(akTarget)
        ConsoleUtil.ExecuteCommand("mfg modifier 0 100")
        ConsoleUtil.ExecuteCommand("mfg modifier 1 100")
    endif
EndEvent

Event OnEffectFinish(Actor akTarget, Actor akCaster)
    if akTarget
        ConsoleUtil.SetSelectedReference(akTarget)
        ConsoleUtil.ExecuteCommand("mfg reset")
    endif
EndEvent
